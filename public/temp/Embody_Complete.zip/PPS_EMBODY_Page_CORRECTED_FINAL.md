# EMBODY P.A.T.H.WAY™ PAGE

## URL: `/partner-with-us/embody` or `/embody`

**Breadcrumb:** Home > Partner With Us > EMBODY P.A.T.H.way

---

## SECTION 1: HERO

### Headline (H1):
**Architect Transformation That Lasts.**

### Subheadline:
EMBODY is for founders and leaders ready to build permanent organizational capacity through deep, sustained partnership. This isn't consulting or change management. This is co-architecting an unshakeable foundation for sustainable transformation and continuous innovation for who your organization is becoming next.

**6-12+ month embedded partnerships. Strategic advisory. Executive guidance. Comprehensive transformation architecture.**

### Hero Visual:
Solid architectural foundation, fortified structure, permanence and strength, organizational scale

### Primary CTA:
**[Start with Blue Door Diagnostic - $697]** → Required first step for EMBODY consideration

---

## SECTION 2: THE EMBODY CLIENT

### Headline (H2):
**You've Made the Decision. Now You Need Aligned Leadership & Strategic Execution.**

### Copy:
You're a C-suite executive who's made the decision: your organization is ready to lead sustainable transformation. You're not looking for consultants to fix you or implement change for you—you're ready for strategic partners to co-architect permanent capability.

**Where you're at:**
- You want co-creation, not outsourcing  
- You've learned that brilliant strategy fails without organizational capacity to execute it
- You understand transformation happens through people, not to them
- You're asking: "Can we even do what we're planning?"
- You're open to slowing down to do it right

**What you know:**
- Great people + great process = extraordinary outcomes
- Transformation without leadership alignment and ownership fails
- You can't architect on top of assumptions—Phase Zero™ reveals candid clarity on operational capability and capacity
- Quick fixes mask structural problems; foundations enable lasting change
- Sustainable transformation requires time for architecture, integration, and embedding

**The EMBODY outcome you're seeking:**

*"We've built the internal structures and culture to architect and execute sustainable change—continual transformation is now ours to lead."*

Transformation becomes self-sustaining and repeatable. Your organization develops permanent capacity and practices that outlasts any single initiative.

---

### What EMBODY Partnership Provides:

**Comprehensive engagement for organizations ready for permanent transformation:**

✓ **6-12+ month embedded partnership** - Strategic advisory and executive co-architecting  
✓ **Complete transformation architecture** - Systematic capability building across your organization  
✓ **Leadership development integration** - Your team learns to architect change, not just execute it  
✓ **Communication strategy and execution** - Organizational alignment systems that stick  
✓ **Change infrastructure design** - Self-sustaining transformation capability built into your DNA

---

### The Partnership Model:

**You're the expert of your organizational context, your culture, your constraints.**  
**We're experts in transformation architecture and Phase Zero™ design.**

Together, we build what actually works in YOUR reality—not what works in theory.

This isn't consulting. This isn't training. This is co-architecting permanent organizational capacity.

---

## SECTION 3: WHAT EMBODY LOOKS LIKE

### Headline (H2):
**The EMBODY Partnership Experience**

### Copy:
Every EMBODY partnership is custom-designed based on your organizational context, transformation ambition, and capacity assessment. But here's the typical structure:

---

### THE EMBODY PROCESS:

---

### [PHASE CARDS LAYOUT - Phases 1 & 2 Side-by-Side]

**PHASE CARD 1: DISCOVERY & DESIGN (30-60 Days)**

**What Happens:**

**Blue Door Diagnostic** (if not completed)
- Comprehensive 11-question organizational assessment
- Written report with Pillar scores
- Strategic dashboard access
- Personal debrief with Amy Yackowski

**Stakeholder Discovery**
- Interviews with key executives and leaders
- Organizational context deep-dive
- Culture and capacity assessment
- Constraint and opportunity identification

**Partnership Design**
- Co-design partnership structure
- Define outcomes and success metrics
- Establish cadences and touchpoints
- Align on roles and accountability

**Deliverable:** Partnership Agreement & Transformation Architecture Blueprint

**Timeline:** 4-8 weeks

---

**PHASE CARD 2: ARCHITECT CHANGE (Ongoing - 6-12+ Months)**

**What Happens:**

**Strategic Advisory**
- Ongoing access to Amy Yackowski and the Painted Porch team of advisors
- Phase Zero™ strategic design sessions
- P.A.T.H.™ framework application to initiatives
- Co-architect transformation strategy that your team can sustain independently
- Decision support and strategic guidance

**Transformation Architecture**
- Design across all three Painted Porch Pillars™:
  - Leadership & Culture (Foundational Architecture)
  - Workflows & Systems (Operational Intelligence)
  - Human Capacity (Judgment & Navigation)
- Custom framework and tool development
- Stakeholder alignment facilitation

**Leadership Development**
- Executive coaching touchpoints
- Team capacity building
- Leadership operating model refinement
- Change Ambassador Network design

**Deliverable:** Living Transformation Architecture (evolves throughout partnership)

**Timeline:** 6-12 months (or longer based on scope)

---

**[PHASE CARD 3: Full Width Below]**

**PHASE CARD 3: EMBED & SUSTAIN (Final 3-6 Months)**

**What Happens:**

**Capability Transfer**
- Build internal capability to sustain architecture
- Train internal champions and facilitators
- Document practices and protocols
- Establish self-sustaining rhythms

**Ongoing Options**
- Invitation to Leadership Summit (semi-annually)
- Retained advisory relationship (as-needed)
- Annual strategic planning partnership
- Complete transition to internal ownership

**Deliverable:** Self-Sustaining Transformation Capacity

**Timeline:** Final 3-6 months of partnership

---

**[VISUAL LAYOUT NOTE FOR DESIGN TEAM:]**

```
Desktop Layout:
[------------------------PHASE CARDS CONTAINER------------------------]
|  PHASE CARD 1              |  PHASE CARD 2                          |
|  Discovery & Design        |  Architect Change                      |
|  (50% width)               |  (50% width)                           |
|  [Content]                 |  [Content]                             |
|                            |                                        |
[--------------------------------------------------------------------]
|                                                                    |
|  PHASE CARD 3: Embed & Sustain                                    |
|  (100% width)                                                      |
|  [Content]                                                         |
|                                                                    |
[--------------------------------------------------------------------]

Mobile Layout:
All three cards stack vertically (Phase 1, Phase 2, Phase 3)
```

**Card Styling:**
- Equal visual weight for all three cards
- Use Painted Porch brand colors (teal accent for Phase 1, purple for Phase 2, gold for Phase 3)
- White background with subtle shadow/border
- Consistent padding and spacing
- Phase numbers/titles as card headers with larger font
- "What Happens" sections with clear hierarchy
- Deliverable and Timeline highlighted at bottom of each card

---

## SECTION 4: THE THREE PAINTED PORCH PILLARS™

### Headline (H2):
**Architect Adaptability Across All Three Pillars of Organizational Strength**

### Subheadline:
The Painted Porch Pillars™ are your organization's structural capabilities for leading the change you're attempting. While most advisors work on one dimension at a time—leadership first, then processes, then people. That creates cracks where transformation fails.

**EMBODY partnerships integrate all three Pillars simultaneously so change capability compounds instead of cracks.**

---

### [PILLAR CARDS LAYOUT - Three Pillars Side-by-Side]

**PILLAR CARD 1: Foundational Architecture (Leadership & Culture)**

**The Questions:**
- Can your leaders author strategic direction—or only respond to demands?
- Will your culture support this transformation—or resist it?
- Do you have the leadership operating model required?

**What We'll Architect:**
- Leadership capacity for strategic authorship
- Cultural platforms where change can be built
- Executive alignment and decision protocols
- Change authorship capability

**Outcomes:**
- Leaders who design change consciously
- Culture that enables rather than undermines transformation
- Strategic capacity at leadership level

---

**PILLAR CARD 2: Operational Intelligence (Workflows & Systems)**

**The Questions:**
- Do your workflows enable your intended market position?
- Are your systems designed for efficiency—or for strategic value?
- Can your operations handle transformation—or will they constrain it?

**What We'll Architect:**
- Workflow design for market leadership
- System integration that enables value creation
- Operational capacity for transformation
- Process architecture aligned with strategy

**Outcomes:**
- Operations that enable strategy (not constrain it)
- Workflows designed for value, not just efficiency
- Systems that support transformation capacity

---

**PILLAR CARD 3: Human Capacity (Judgment & Navigation)**

**The Questions:**
- Can your people navigate ambiguity—or only execute defined processes?
- Is judgment distributed throughout your organization—or centralized?
- Do you have adaptive capacity—or just implementation skills?

**What We'll Architect:**
- Distributed judgment capability
- Navigation skills for complexity
- Adaptive capacity that can't be automated
- Resilience and strategic thinking throughout your organization

**Outcomes:**
- People who can navigate ambiguity with confidence
- Judgment distributed appropriately across your organization
- Adaptive capacity for continuous transformation

---

**[INTEGRATION CARD: Full Width Below]**

**THE INTEGRATION CARD: When All Three Pillars Are Load-Bearing**

**When all three Pillars are load-bearing:**
- Better architecture → Better operations → Better capability → Better architecture
- The system reinforces itself
- Transformation becomes self-sustaining
- You've built **The Fortified Porch™**—organizational capacity for continuous change

**That's what EMBODY partnerships create.**

---

**[VISUAL LAYOUT NOTE FOR DESIGN TEAM:]**

```
Desktop Layout:
[------------------------PILLAR CARDS CONTAINER------------------------]
|  PILLAR 1          |  PILLAR 2          |  PILLAR 3              |
|  Foundational      |  Operational       |  Human Capacity        |
|  Architecture      |  Intelligence      |                        |
|  (33% width)       |  (33% width)       |  (33% width)           |
|  [Content]         |  [Content]         |  [Content]             |
|                    |                    |                        |
[--------------------------------------------------------------------]
|                                                                    |
|  THE INTEGRATION: When All Three Pillars Are Load-Bearing         |
|  (100% width)                                                      |
|  [Content]                                                         |
|                                                                    |
[--------------------------------------------------------------------]

Mobile/Tablet Layout:
All four cards stack vertically (Pillar 1, Pillar 2, Pillar 3, Integration)
```

**Card Styling:**
- Equal visual weight for all three Pillar cards
- White background with subtle shadow/border
- Consistent padding and spacing (suggest 24px)
- Equal height for Pillars 1, 2, 3 on desktop
- Integration card: Full width below with distinct styling (perhaps slightly darker background or heavier border to show it's a synthesis)

**Color Accents (Painted Porch Brand):**
- **Pillar 1 (Foundational Architecture):** Teal accent (#4FB3AA)
- **Pillar 2 (Operational Intelligence):** Purple accent (#7B59C6)
- **Pillar 3 (Human Capacity):** Gold/Orange accent (#F8B739)
- **Integration Card:** Navy accent (#2C3E50) or combine all three colors as gradient/multi-color border to show integration

**Accent Usage Options:**
- Top border (4px) in pillar color
- Left border (4px) in pillar color
- Subtle background tint (5% opacity of pillar color)
- Icon/graphic in pillar color

**Typography Hierarchy:**
```
Pillar Title (e.g., "PILLAR 1: Foundational Architecture"):
- Font: Poppins Bold
- Size: 18-20px
- Color: Pillar accent color
- Transform: Uppercase for "PILLAR 1", Title Case for name

Subtitle (e.g., "Leadership & Culture"):
- Font: Montserrat Regular Italic
- Size: 14px
- Color: Medium gray

Section Headers (e.g., "The Questions:", "What We'll Architect:"):
- Font: Poppins SemiBold
- Size: 16px
- Color: Dark gray/black

Bullet Points:
- Font: Montserrat Regular
- Size: 14-15px
- Line height: 1.6
- Color: Medium gray

Integration Card Title:
- Font: Poppins Bold
- Size: 20-22px
- Color: Navy or combined brand colors
- Centered or left-aligned based on design preference
```

**Spacing:**
- **Gap between Pillar cards:** 20px
- **Gap between top row and Integration card:** 32px (slightly larger to show hierarchy)
- **Margin around entire card container:** 40px top/bottom
- **Section spacing within cards:** 16px between sections
- **Bullet spacing:** 8px between bullets

**Responsive Behavior:**
```
Desktop (1200px+):
- Pillars 1, 2, 3: 33.33% width each minus gaps
- Integration: 100% width

Tablet (768px - 1199px):
- Stack Pillars vertically OR keep 3-across if content fits
- Integration: 100% width
- Reduce padding to 20px

Mobile (<768px):
- All cards: 100% width, stacked vertically
- Card order: Pillar 1, 2, 3, Integration
- Reduce padding to 16px
- Maintain visual hierarchy with color accents
```

**Integration Card Distinction:**
To visually distinguish the Integration card as a synthesis/summary:
- Option 1: Slightly darker background (#F8F9FA)
- Option 2: Thicker border (2px vs 1px on Pillars)
- Option 3: Gradient border using all three pillar colors
- Option 4: Centered content with icon/graphic showing interconnection
- Option 5: Navy background with white text (bold statement)

---

## SECTION 5: INVESTMENT & ROI

### Headline (H2):
**Build Continual Innovation & Sustainable Transformation**

### Copy:
EMBODY partnerships are designed to make change a habit, where you own and lead your continuous evolution versus simply manage your next change project.

They are custom-designed based on your organizational scope, transformation ambition, and partnership duration.

**Typical Investment: $90,000 - $360,000+ annually (less than 1% of your annual revenue)**

This is a strategic investment in permanent organizational capacity—not a project expense.

---

### What You're Investing In:

✅ **Permanent transformation architecture we co-architect with your leadership** - Designed for your context, owned by your organization, capability that outlasts any single initiative  
✅ **Strategic partnership with transformation architects** - Deep expertise applied to YOUR context  
✅ **Phase Zero™ foundations** - Strategic clarity before resource commitment  
✅ **Self-sustaining organizational capacity** - Your team learns to architect change independently  
✅ **Co-designed transformation infrastructure** - Built specifically for your reality, not theory  

**The outcome:** You build the internal structures and culture to architect and execute sustainable change—where continual transformation becomes yours to lead.

---

### The ROI of Strategic Architecture:

**Organizations with transformation architecture:**

- **Navigate change without crisis or burnout**  
  *Not because crisis won't happen, but you'll be prepared to address it without panic or setbacks*

- **Scale capabilities as fast as they scale operations**  
  *Not because they "move fast and break things" but through sustained, structural change standards and principles*

- **Make strategic pivots confidently**  
  *Because they're built for adaptation and innovation*

- **Retain talent**  
  *Because transformation doesn't break people and is part of their cultural DNA*

- **Create competitive advantage**  
  *Because they have the capacity and capability for continual, high-performance change*

**The ultimate outcome:** Your team becomes transformation architects who no longer need external partnership. This is success—we build you not to need us.

---

## SECTION 6: THE BLUE DOOR DIAGNOSTIC

### Headline (H2):
**Strategic Clarity Before Partnership Commitment**

### Copy:
You can't architect transformation on assumptions. Blue Door Diagnostic assesses your organizational capacity across the Painted Porch Pillars™, determines EMBODY partnership fit, and provides the strategic foundation for partnership design.

**Investment:** $697 (fully credited toward EMBODY partnership)

**[Learn More About Blue Door]** → Link to dedicated Blue Door page

**[Start Blue Door Diagnostic - $697]**

---

## SECTION 7: WHO WE WORK WITH

### Headline (H2):
**Organizations We Partner With**

### Copy:
EMBODY partnerships aren't limited by industry—they're defined by organizational readiness and executive commitment to building transformation capability that becomes permanently yours.

---

### [COLUMN CARDS - 4 across]

**Healthcare Organizations**
- Navigating industry disruption
- Building strategic capacity for continuous change
- Architecting cultural transformation

**Technology Companies**
- Scaling through hypergrowth
- Leadership development during rapid expansion
- Operational architecture for scale

**Professional Services Firms**
- Strategic repositioning
- Leadership transition preparation
- Building transformation capability

**Non-Profit Organizations**
- Mission realignment and strategic clarity
- Building capacity for sustainable impact
- Leadership team development

---

### What They Share:

✓ C-suite commitment to transformation  
✓ Organizational readiness for deep work  
✓ Recognition that quick fixes don't work  
✓ Partnership mindset ("we architect together")  
✓ Long-term orientation (not project-based thinking)  

---

## SECTION 8: TESTIMONIALS

### Headline (H2):
**Organizations That Have Embodied Transformation**

---

### TESTIMONIAL 1:
> "We thought we needed change management consultants. What we got was so much more valuable—strategic partners who helped us architect transformation capacity we'll have forever. The Blue Door revealed we weren't ready. The 18-month partnership built foundations that now support everything we do. Worth every dollar."
>
> **— [Name], CEO, [Company]**  
> *18-month EMBODY partnership, now independent*

---

### TESTIMONIAL 2:
> "Amy doesn't tell you what to do. She asks questions that reveal what you already know but haven't articulated. Our leadership team went from fragmented to aligned. Our culture went from resistant to enabling. We're now leading transformation that would have failed two years ago."
>
> **— [Name], Chief Strategy Officer, [Company]**  
> *12-month EMBODY partnership, continuing with Leadership Summits*

---

### TESTIMONIAL 3:
> "The EMBODY partnership wasn't comfortable. Amy challenged assumptions we'd held for years. She asked whether we were actually ready (we weren't). But she also partnered with us to build the capacity we needed. Now we architect change consciously instead of reacting to pressure. That's permanent competitive advantage."
>
> **— [Name], Chief People Officer, [Company]**  
> *24-month EMBODY partnership across two major transformations*

---

## SECTION 9: FAQ

### Headline (H2):
**Frequently Asked Questions**

#### Q: How is your EMBODY partnership different from traditional consulting?
**A:** Traditional consultants deliver best practice solutions for you based on what worked elsewhere. We partner with you to co-design transformation architecture specific to your context. You're the expert of your organization. We're experts in transformation architecture. Together, we build permanent capacity—not packaged solutions or project deliverables.

#### Q: How is your EMBODY partnership different from change management consultants?
**A:** Change management focuses on implementing predefined changes by managing resistance, driving adoption, and delivering transitions downstream. We do change origination—we partner with you to architect transformation capacity upstream, before implementation begins. Change management delivers projects and manages transitions. We co-architect permanent transformation capability. After change management, you've executed a change. After EMBODY partnership, you've built the capacity to originate and architect your own transformations without external dependency.

#### Q: Can we start with AMPLIFY and progress to EMBODY?
**A:** Absolutely. Many organizations start with AMPLIFY workshop or sprint to test partnership fit, then progress to EMBODY when deeper work makes sense.

#### Q: Do we need Blue Door before scheduling discovery?
**A:** Not required, but highly recommended. Blue Door provides organizational assessment that informs discovery conversation and partnership design.

#### Q: What if we complete Blue Door and don't qualify?
**A:** We'll be honest about readiness. If gaps exist, we'll recommend how to build capacity (often through AMPLIFY or IGNITE first). When organizational readiness improves, we can reassess.

#### Q: How often do you meet with us during our EMBODY partnership?
**A:** Typically bi-weekly or monthly formal sessions, plus regular office hours access between sessions. Exact cadence is co-designed based on your needs and transformation pace.

#### Q: Can you work with our internal change management team?
**A:** Yes. We often partner with internal teams, building their capacity while providing strategic guidance. We're not competitive with internal teams—we're complementary.

#### Q: What happens if leadership changes during partnership?
**A:** We work through leadership transitions as part of the partnership. Often, leadership transition is exactly when transformation architecture matters most.

**[More Questions? Contact Us]**

---

## SECTION 10: FINAL INVITATION

### Headline (H2):
**"Continual Transformation Is Now Ours to Lead."**

### Copy:
**That's the EMBODY outcome. But not every organization is ready for it yet.**

Some need to start with IGNITE (individual capacity). Some need AMPLIFY first (team alignment). Some need to build organizational readiness before deep partnership makes sense.

**And that's completely okay.**

But if you're a C-suite executive who understands:
- **Transformation happens through people, not to them**
- You need strategic partners to co-architect—not consultants to implement change for you
- Your organization is asking: **"Can we even do what we're planning?"**
- You're ready for permanent capability built into your DNA

**Then let's explore whether EMBODY partnership makes sense.**

---

### Your P.A.T.H.way™ to EMBODY Lasting Transformation:

**Step 1: Blue Door Diagnostic**  
Comprehensive organizational assessment ($697, credited toward engagement)

**Step 2: Results & Debrief**  
Strategic conversation with Amy about readiness and fit

**Step 3: Discovery (If Qualified)**  
Co-design partnership structure, outcomes, and investment

**Step 4: Partnership Agreement**  
Formalize commitment and begin transformation architecture

---

### [SIDE-BY-SIDE CTA CARDS]

**CTA CARD 1: Begin with Blue Door Diagnostic**

Blue Door assesses your organizational capacity across the Painted Porch Pillars™ and determines EMBODY partnership fit. Complete the assessment, receive your strategic report, then we'll schedule a partnership exploration conversation.

**[Start Blue Door Diagnostic - $697]**

---

**CTA CARD 2: Questions About EMBODY Partnership?**

Complete our partnership inquiry form with your organizational context and questions. We'll review and connect with resources and next steps.

**[Contact Us About Partnership]**

---

**[VISUAL LAYOUT NOTE FOR DESIGN TEAM:]**  
These two CTA cards should be displayed side-by-side (50/50 width on desktop, stacked on mobile) directly under the 4-step P.A.T.H.way process. Equal visual weight, equal sizing. No separate section headings above them.

---

### Closing Copy:

**ShIFt happens. Will you architect it—or react to it?**

You understand **transformation happens through people, not to them**. That brilliant strategy fails without organizational capacity. That you can't architect on top of assumptions.

**You're the expert** of your organizational context, your culture, your constraints.  
**We're experts** in transformation architecture and Phase Zero™ design.

**Together,** we build what works in YOUR reality—permanent capacity where **continual transformation becomes yours to lead**.

**This is your invitation to co-architect what comes next.**

---

## FOOTER

*(Standard site footer with full navigation)*

---

**END OF ALL THREE P.A.T.H.WAY™ TIER PAGES**

---

## IMPLEMENTATION NOTES FOR ALL THREE PAGES

### Common Elements:
- Consistent brand voice and positioning
- Phase Zero™ emphasized throughout
- Partnership language (not consulting services)
- Invitation-based CTAs (not demanding)
- Clear progression paths between tiers
- ~6th grade reading level maintained

### Key CTAs Across Pages:
- "Take Free P.A.T.H. Finder" (IGNITE primary)
- "Contact Us" (AMPLIFY/EMBODY secondary)
- "Start Blue Door Diagnostic - $697" (EMBODY primary)
- "Explore [Other Tier]" (cross-tier navigation)

### Visual Design Consistency:
- Three-tier color coding (Teal=IGNITE, Purple=AMPLIFY, Gold=EMBODY)
- Architectural imagery and metaphors
- Clean layouts with generous whitespace
- Mobile-responsive throughout

